export HDLGEN_ROOT=`pwd`
