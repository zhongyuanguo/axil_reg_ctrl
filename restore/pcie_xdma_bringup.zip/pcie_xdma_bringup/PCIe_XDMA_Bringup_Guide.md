# PCIe XDMA Bringup Guide

## 1. Prerequest

This is a guide for Xilinx PCIe XDMA device bringup. Before the task start, a design include the IP 'DMA/Bridge Subsystem for PCI Express' should be ready. For example, below shown a design of communication network with this IP. Options in red rectangle are changed from default setting. Make sure everything is OK.

![alt Fig 1.1](./xdma_option_0.png)
Figure 1.1

![alt Fig 1.2](./xdma_option_1.png)
Figure 1.2

![alt Fig 1.3](./xdma_option_2.png)
Figure 1.3

The diagram of communication network and address map are shown in following figures.
![alt Fig 1.4](./network_design.png)
Figure 1.4

![alt Fig 1.5](./network_address.png)
Figure 1.5

## 2. XDMA Driver Install

### 2.1 Fix issues about driver

Get the driver package from [github site](https://github.com/Xilinx/dma_ip_drivers/tree/master). The linux-kernel of XDMA driver is under the directory 'XDMA/linux-kernel'. 

Correct some mistake in source files as following shown.

1. File 'cdev_sgdma.c', function bodies for cdev_write_iter and cdev_read_iter, need too change from 'io->iov' to 'io->__iov';
2. File 'xdma_cdev.c', line 606, change call of 'class_create(THIS_MODULE, XDMA_NODE_NAME)' to 'class_create(XDMA_NODE_NAME)'
3. File 'cdev_ctrl.c', line 235. Need to add conversion of 'vma->vm_flags' to 'vm_area_struct *'

```c
vm_flags_set(vma, VMEM_FLAGS);
```

Note: Some reports say an new function is needed as following shown. In fact, when I add this to 'cdev_ctrl.c' and compile the kernal, an error is reported for redefine this function. So I commited these lines of function define.

```c
void vm_flags_set(struct vm_area_struct *vma, vm_flags_t flags) {
    vma->vm_flags |= flags;
}
```

### 2.2 Install driver of XDMA

1. Change to the directory 'XDMA/linux-kernel/xdma' and install the driver by this command 'sudo make install'.
2. Change to the dirctory 'XDMA/linux_kernel/tests'. Load the driver by this command 'sudo ./load_driver.sh'
3. When the driver is loaded successfully, 'DONE' is shown.
![alt Fig 2.1](./install_ok.png)  
4. Check the device of XDMA by this command 'ls /dev/xdma*'
![alt Fig 2.2](./xdma_devices.png)
/dev/xdma0_c2h_0: Chip to Host Channel
/dev/xdma0_h2c_0: Host to Chip Channel
/dev/xdma0_control: Access to XDMA Control Registers
5. Check the detail information about PCIe vender by this command 'sudo lspci -vvvs 06:00.0'
![alt Fig 2.3](./xdma_vender_info.png)

### 2.3 Read and Write Test

1. Compile the tools for test. Change to the directory 'XDMA/linux-kernal/tools'. Use this command 'sudo make'. The tools are shown in following figure.
![alt Fig 2.4](./xdma_test_tools.png)
2. Write test as following shown. The file 'in.mem' contains data to transfer by XDMA.
![alt Fig 2.5](./dma_to_device.png)
3. Read test as following shown. The file 'out.mem' contains data read back by XDMA.
![alt Fig 2.6](./device_to_dma.png)
